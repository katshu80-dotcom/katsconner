<?php
    include 'banner.php';
    if(isset($_GET['id'])) {
        $product_id = intval($_GET['id']);
        $query = "SELECT * FROM products WHERE id=$product_id";
        $result = mysqli_query($conn, $query);
        $product = mysqli_fetch_assoc($result);


    }
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['addCart'])) {
        $p_id = intval($_POST['product_id']);
        $qty = intval($_POST['quantity']);
        $price = floatval($_POST['price']);
        $name = strval($_POST['name']);

        $_SESSION['cart'][$p_id] = [
            'name' => $name,
            'quantity' => $qty,
            'price' => $price
        ];
    }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="mainStyle.css?v=<?php echo time(); ?>">
    </head>
    <body>

        <div class="detailsCon">

            <div class="detailsImage">
                <img src="<?php echo $product['image']; ?>" alt="Product" >
            </div>

            <div class="detailsInfo">
                <h1><?php echo $product['name']; ?></h1>
                <h2>Price:</h2>
                <p class="price">R<?php echo $product['price']; ?></p>
                <h2>Description:</h2>
                <p class="description"><?php echo $product['details']; ?></p>




                <form action="" method="POST" >
                    <input type="hidden" name="name" value="<?php echo $product['name']; ?>">
                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                    <input type="hidden" name="price" value="<?php echo $product['price']; ?>">
                    <label for="quantity">Select Quantity:</label>
                    <select name="quantity" id="quantity">
                        <?php 
                            $i = 1; 
                            $max = $product['quantity']; 

                            while ($i <= $max) {
                                echo "<option value='$i'>$i</option>";
                                $i++; 
                            }
                        ?>
                    </select>
                    <p id="priceDisplay">Total: R</p>
                    <button type="submit" class="add-btn" name="addCart" id="cartBtn">Add to Cart</button>
                </form>


            </div>
        </div>
    </body>
</html>

<script>
    const qtyDropdown = document.getElementById('quantity');
    const totalDisplay = document.getElementById('priceDisplay');
    const cartBtn = document.getElementById('cartBtn');
    const unitPrice = <?php echo $product['price']; ?>;

    qtyDropdown.addEventListener('change', function() {
        const total = this.value * unitPrice;
        totalDisplay.innerText = "Total: R" + total.toFixed(2);
    });
    cartBtn.addEventListener('click', function(){
        alert("<?php echo mysqli_real_escape_string($conn, $product['name']); ?> was added to cart!")
    })

</script>


    

