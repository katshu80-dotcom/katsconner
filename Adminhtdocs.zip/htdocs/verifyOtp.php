<?php 
    session_start();

    $msg = "";
    if(isset($_SESSION['otp'])) {
        echo "Testing: Your OTP is " . $_SESSION['otp'];
    }
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $user_input = $_POST['otp'];
        if ($user_input == $_SESSION['otp']) {
            unset($_SESSION['otp']); 
            $_SESSION['logStatus']="Logged in";
            header("Location: home.php?msg=Success");
            exit();
           
        } else {
            $msg = "Invalid OTP code. Please try again.";
        }
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Log in</title>
        <link rel="stylesheet" href="adminStyle.css">
    </head>
    <body>
        <h1>Enter OTP</h1>
        <?php if($msg) echo "<p style='color:red;'>$msg</p>"; ?>
        <form action="" method="post">
            <label>OTP</label>
            <input type="password" name="otp" required>
            <input type="submit" value="Verify">
        </form>
    </body>
</html>