<?php 
    include 'adminSql.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['productId'];
        $action = $_POST['action'];
        $reason = $_POST['reason'];


        if ($action == "approve") {
            $sql = "UPDATE products SET status = 1 WHERE id = ?";
        } elseif ($action == "decline") {
            $sql = "UPDATE products SET status = 2, rejectReason = ? WHERE id = ?";
        } else {
            
            header("Location: pendingP.php");
            exit();
        }

        $prep = mysqli_prepare($conn, $sql);
        
        if ($action == "approve") {
            mysqli_stmt_bind_param($prep, "i", $id);
        } else {
            mysqli_stmt_bind_param($prep, "si", $reason, $id);
        }

        mysqli_stmt_execute($prep);
        header("Location: home.php"); 
        exit();
    }
?>