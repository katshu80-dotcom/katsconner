<?php
    include 'adminSql.php';
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_category'])) {
        $category=$_POST['category'];
        $sql="INSERT INTO category(name) VALUES(?)";
        $prep=mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($prep,"s",$category);
        if (mysqli_stmt_execute($prep)) {
            echo "{$category} is in the database.";
        } else {
            echo "Error: Could not save category.";
        }
    }
    include 'banner.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Category</title>
        <link rel="stylesheet" href="adminStyle.css">
    </head>
    <body>
        <form action="" method="post">
            <label>Category</label><br>
            <input type="text" name="category" required><br>
            <input type="submit" name="save_category" value="Save" class="logBtn">
        </form>
    </body>
    
</html>
