<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    include 'adminSql.php';
    include 'banner.php';


    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['updateCategory'])) {
        $product_id = intval($_POST['product_id']);
        $new_category_id = intval($_POST['prodCategory']);
        
        $update_query = "UPDATE products SET category_id = $new_category_id WHERE id = $product_id";
        mysqli_query($conn, $update_query);
        
        $target_uid = intval($_POST['user_id']);
        $target_uname = mysqli_real_escape_string($conn, $_POST['username']);
    } 
    
    elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['updateListingStatus'])) {
        $product_id = intval($_POST['product_id']);
        $new_status = mysqli_real_escape_string($conn, $_POST['prodStatus']);
        
        $update_query = "UPDATE products SET status = '$new_status' WHERE id = $product_id";
        mysqli_query($conn, $update_query);
        
        $target_uid = intval($_POST['user_id']);
        $target_uname = mysqli_real_escape_string($conn, $_POST['username']);
    }
    
    elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['user_id'])) {
        $target_uid = intval($_POST['user_id']);
        $target_uname = mysqli_real_escape_string($conn, $_POST['username']);
    } else {
        header("Location: users.php");
        exit();
    }

    
    $image_path_prefix = "https://katsconner.great-site.net/"; 

    
    $listed_query = "SELECT p.id, p.name, p.price, p.category_id, p.status, p.quantity, p.image, c.name AS category_name 
                     FROM products p
                     LEFT JOIN category c ON p.category_id = c.id
                     WHERE p.userId = $target_uid";
    $listed_data = mysqli_query($conn, $listed_query);

    $sold_query = "SELECT p.name AS prod_name, u.username AS buyer_name, s.quantity, s.price, s.status AS delivery_status 
                   FROM sales s 
                   JOIN products p ON s.prod_id = p.id 
                   JOIN users u ON s.user_id = u.userId 
                   WHERE p.userId = $target_uid";
    $sold_data = mysqli_query($conn, $sold_query);

    $bought_query = "SELECT p.name AS prod_name, u.username AS seller_name, s.quantity, s.status AS order_status 
                     FROM sales s 
                     JOIN products p ON s.prod_id = p.id 
                     JOIN users u ON p.userId = u.userId 
                     WHERE s.user_id = $target_uid";
    $bought_data = mysqli_query($conn, $bought_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Profile Details</title>
    <link rel="stylesheet" href="adminStyle.css">
</head>
<body>

    <div class="details-container">
        <div class="back-nav">
            <a href="users.php" class="back-btn" style="color: #FFCC00; text-decoration: none; font-weight: bold;">← Back to Management</a>
        </div>
        
        <h2 class="profile-header">Profile Details for: <span><?php echo htmlspecialchars($target_uname); ?></span></h2>

        <h3 class="section-title">Products Listed</h3>
        <table class="details-table">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Category Management</th>
                    <th>Status Control</th>
                    <th>Qty</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($listed_data && mysqli_num_rows($listed_data) > 0): ?>
                    <?php while ($prod = mysqli_fetch_assoc($listed_data)): ?>
                        <tr>
                            <td>
                                <?php if (!empty($prod['image'])): ?>
                                    <img src="<?php echo $image_path_prefix . htmlspecialchars($prod['image']); ?>" alt="Product" class="table-img">
                                <?php else: ?>
                                    <div class="no-img-placeholder">No Image</div>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($prod['name']); ?></td>
                            <td>R<?php echo number_format($prod['price'], 2); ?></td>
                            <td>
                                <form action="" method="POST" class="inline-change-form">
                                    <input type="hidden" name="product_id" value="<?php echo $prod['id']; ?>">
                                    <input type="hidden" name="user_id" value="<?php echo $target_uid; ?>">
                                    <input type="hidden" name="username" value="<?php echo htmlspecialchars($target_uname); ?>">
                                    <select name="prodCategory" class="table-select" style="background-color: black; color: white; border: 1px solid #FFCC00; padding: 5px;">
                                        <?php
                                            $cat_query = "SELECT id, name FROM category";
                                            $cat_result = mysqli_query($conn, $cat_query);
                                            while($cat_row = mysqli_fetch_assoc($cat_result)){
                                                $selected = ($cat_row['id'] == $prod['category_id']) ? "selected" : "";
                                                echo "<option value='" . $cat_row['id'] . "' $selected>" . htmlspecialchars($cat_row['name']) . "</option>";
                                            }
                                        ?>
                                    </select>
                                    <button type="submit" name="updateCategory" class="save-table-btn" style="padding: 5px 10px; font-weight: bold; background-color: #FFCC00; color: #003366; border: none; cursor: pointer; border-radius: 4px;">Update</button>
                                </form>
                            </td>
                            <td>
                                <form action="" method="POST" class="inline-change-form">
                                    <input type="hidden" name="product_id" value="<?php echo $prod['id']; ?>">
                                    <input type="hidden" name="user_id" value="<?php echo $target_uid; ?>">
                                    <input type="hidden" name="username" value="<?php echo htmlspecialchars($target_uname); ?>">
                                    <select name="prodStatus" class="table-select" style="background-color: black; color: white; border: 1px solid #FFCC00; padding: 5px;">
                                        <option value="1" <?php if($prod['status'] == '1') echo 'selected'; ?>>1 (Active/Visible)</option>
                                        <option value="0" <?php if($prod['status'] == '0') echo 'selected'; ?>>0 (Hidden/Review)</option>
                                        <option value="2" <?php if($prod['status'] == '2') echo 'selected'; ?>>2 (Archived)</option>
                                    </select>
                                    <button type="submit" name="updateListingStatus" class="save-table-btn" style="padding: 5px 10px; font-weight: bold; background-color: #FFCC00; color: #003366; border: none; cursor: pointer; border-radius: 4px;">Set</button>
                                </form>
                            </td>
                            <td><?php echo intval($prod['quantity']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="empty-row">No active product listings found for this profile.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <h3 class="section-title">Products Sold</h3>
        <table class="details-table">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Buyer</th>
                    <th>Quantity Sold</th>
                    <th>Total Received</th>
                    <th>Delivery Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($sold_data && mysqli_num_rows($sold_data) > 0): ?>
                    <?php while ($sold = mysqli_fetch_assoc($sold_data)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($sold['prod_name']); ?></td>
                            <td><?php echo htmlspecialchars($sold['buyer_name']); ?></td>
                            <td><?php echo intval($sold['quantity']); ?></td>
                            <td>R<?php echo number_format($sold['price'] * $sold['quantity'], 2); ?></td>
                            <td>
                                <span class="status-pill <?php echo strtolower(htmlspecialchars($sold['delivery_status'])); ?>">
                                    <?php echo htmlspecialchars($sold['delivery_status']); ?>
                                </span>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="empty-row">No recorded completed sales found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <h3 class="section-title">Products Bought</h3>
        <table class="details-table">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Seller From</th>
                    <th>Quantity Bought</th>
                    <th>Order Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($bought_data && mysqli_num_rows($bought_data) > 0): ?>
                    <?php while ($bought = mysqli_fetch_assoc($bought_data)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($bought['prod_name']); ?></td>
                            <td><?php echo htmlspecialchars($bought['seller_name']); ?></td>
                            <td><?php echo intval($bought['quantity']); ?></td>
                            <td>
                                <span class="status-pill <?php echo strtolower(htmlspecialchars($bought['order_status'])); ?>">
                                    <?php echo htmlspecialchars($bought['order_status']); ?>
                                </span>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="empty-row">No recorded procurement transactions found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>
</html>