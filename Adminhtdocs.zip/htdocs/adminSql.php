<?php
    $db_server="sql212.infinityfree.com";
    $db_user="if0_41999338";
    $db_pass="gDeHCH6tbr6J";
    $db_name="if0_41999338_kcdb";
    $conn="";
    
    try{
        $conn=mysqli_connect($db_server,$db_user,$db_pass,$db_name);
    }
    catch(mysqli_sql_exception){
        echo"Failed to connect";
    }
?>