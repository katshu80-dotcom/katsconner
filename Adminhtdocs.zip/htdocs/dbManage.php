<?php
    include 'banner.php';

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Others</title>
        <link rel="stylesheet" href="adminStyle.css">
    </head>
    <body>
        
        <a href="categories.php" >
            <button class="homeBtn"> Categories </button>
        </a><br>
    </body>
    
</html>