<?php
    include 'banner.php'
?>


<!DOCTYPE html>
<html>
    <head>
        <title>Products</title>
        <link rel="stylesheet" href="adminStyle.css">
    </head>
    <body>
        
        <a href="pendingP.php" >
            <button class="homeBtn"> Products </button>
        </a><br>
    </body>
    
</html>