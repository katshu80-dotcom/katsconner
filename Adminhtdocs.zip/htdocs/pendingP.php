<?php
include 'adminSql.php';

$query = "SELECT * FROM products WHERE status = 0 LIMIT 1";
$result = mysqli_query($conn, $query);
$product = mysqli_fetch_assoc($result);

$admin_image = "http://katsconner.great-site.net/";

if (!$product) {
    echo "<h2>All caught up! No pending products.</h2>";
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Approvals</title>
    <link rel="stylesheet" href="adminStyle.css">
</head>
<body>
        <div class="approval-card">
            <h2>Approve Product: <?php echo $product['name']; ?></h2>
            <img src="<?php echo $admin_image.$product['image']; ?>" width="200">
            <p>Price: R<?php echo $product['price']; ?></p>
            <p>Quantity: <?php echo $product['quantity']; ?></p>
            <p>details: <?php echo $product['details']; ?></p>

            <form action="productsAD.php" method="POST">
                <input type="hidden" name="productId" value="<?php echo $product['id']; ?>">

                <button type="submit" name="action" value="skip">Skip</button>
                <button type="submit" name="action" value="approve">Approve</button>
                <button type="button" onclick="showDeclineBox()">Decline</button>

               <div id="declineBox" style="display:none; margin-top: 15px;">
                    <label style="color: red;"><strong>Please provide a reason for rejection:</strong></label><br>
                    <textarea name="reason" id="reason" rows="3" placeholder="e.g., Image is too blurry..."></textarea><br>
                    <button type="submit" name="action" value="decline">Confirm Decline</button>
                </div>
            </form>
        </div>
    <?php } ?>
<script>
function showDeclineBox() {
    var box = document.getElementById('declineBox');
    var reasonInput = document.getElementById('reason');
    
    box.style.display = "block";
    
    reasonInput.required = true;
    reasonInput.focus();
}
</script>
</body>
</html>