<?php 
    session_start();
    include 'adminSql.php';

    $msg="";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $password=$_POST['password'];
 
        if ($password == $_SESSION['password2']) {
            echo "Password Correct";
            $otp = rand(100000, 999999);
            $_SESSION['otp']=$otp;
            unset($_SESSION['password2']); 
            header("Location: verifyOtp.php?msg=Success");
            exit();
        } else {
            $msg= "Invalid password.";
        }
            
    
            
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Log in</title>
        <link rel="stylesheet" href="adminStyle.css">
    </head>
    <body >
        <h2>Log In</h2>
        <?php if($msg) echo "<p style='color:red;'>$msg</p>"; ?>
        <p>Enter your password in the field below:</p>
        <form action="" method="post">
            <label>Password</label>
            <input type="password" name="password" required><br>
            <input type="submit" value="Log In">
        </form>
    </body>

</html>