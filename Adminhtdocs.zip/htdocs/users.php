<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    include 'adminSql.php';
    include 'banner.php';
    
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['updateUserStatus'])) {
        $target_user_id = intval($_POST['managed_user_id']);
        $new_status = mysqli_real_escape_string($conn, $_POST['AccountStatus']);
        
        $update_query = "UPDATE users SET status = '$new_status' WHERE userId = $target_user_id";
        mysqli_query($conn, $update_query);
        
        echo "<script>window.location.href = window.location.href;</script>";
        exit();
    }

    $querys = "SELECT 
                u.userId, 
                u.username, 
                u.status, 
                u.date,
                (SELECT COUNT(*) FROM products WHERE products.userId = u.userId) AS products_listed,
                (SELECT COUNT(*) FROM sales s JOIN products p ON s.prod_id = p.id WHERE p.userId = u.userId) AS products_sold,
                (SELECT COUNT(*) FROM sales WHERE sales.user_id = u.userId) AS products_bought
               FROM users u 
               ORDER BY u.username ASC";

    $data = mysqli_query($conn, $querys);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Management</title>
    <link rel="stylesheet" href="adminStyle.css">
</head>
<body>

    <div class="orders-section">
        <h2 class="order-title" style="color: #FDFDFD; margin-bottom: 20px;">Account Moderation</h2>
        
        <?php 
        if (isset($data) && mysqli_num_rows($data) > 0):
            mysqli_data_seek($data, 0);
            while ($sale = mysqli_fetch_assoc($data)): 
        ?>
                <div class="dropdown-container" style="padding: 20px; background-color: #003366; border: 3px solid #FFCC00; margin-bottom: 15px; color: #FDFDFD;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <form id="view_user_form_<?php echo $sale['userId']; ?>" action="userDetails.php" method="POST" style="display:inline;">
                            <input type="hidden" name="user_id" value="<?php echo $sale['userId']; ?>">
                            <input type="hidden" name="username" value="<?php echo htmlspecialchars($sale['username']); ?>">
                            <button type="submit" class="cart-product-link" style="background: none; border: none; color: #FDFDFD; font-size: 18px; font-weight: bold; cursor: pointer; text-decoration: underline; padding: 0;">
                                Username: <?php echo htmlspecialchars($sale['username']); ?>
                            </button>
                        </form>
                        <span style="font-size: 16px;">Status: <strong><?php echo htmlspecialchars($sale['status']); ?></strong></span>
                    </div>
                    
                    <p><strong>Total Items Listed:</strong> <?php echo intval($sale['products_listed']); ?></p>
                    <p><strong>Total Items Sold:</strong> <?php echo intval($sale['products_sold']); ?></p>
                    <p><strong>Total Items Bought:</strong> <?php echo intval($sale['products_bought']); ?></p>
                    <p><strong>Registration Date:</strong> <?php echo htmlspecialchars($sale['date']); ?></p>
                    
                    <form action="" method="POST" id="mod_form_<?php echo $sale['userId']; ?>" style="margin-top: 15px; padding-top: 10px;">
                        <input type="hidden" name="managed_user_id" value="<?php echo $sale['userId']; ?>">
                        <input type="hidden" id="username_<?php echo $sale['userId']; ?>" value="<?php echo htmlspecialchars($sale['username']); ?>">
                        
                        <div style="border-bottom: 1px dashed #003366; padding-bottom: 10px; margin-bottom: 10px;">
                            <label style="font-weight: bold; color: #FDFDFD;">Update Account Status:</label>
                            <select name="AccountStatus" id="status_select_<?php echo $sale['userId']; ?>" class="largenFields" style="background-color: #003366; color: #FDFDFD; padding: 5px; margin-left: 10px;">
                                <option value="Active" <?php if($sale['status'] == 'Active') echo 'selected'; ?>>Active</option>
                                <option value="Banned" <?php if($sale['status'] == 'Banned') echo 'selected'; ?>>Banned</option>
                            </select>
                            <button type="submit" name="updateUserStatus" onclick="return confirmModeration(<?php echo $sale['userId']; ?>);" style="padding: 5px 10px; margin-left: 10px; font-weight: bold; cursor: pointer;">Save Status</button>
                        </div>
                    </form>
                </div>
        <?php 
            endwhile; 
        endif; 
        ?>
    </div>

</body>

<script>
    function confirmModeration(userId) {
        const username = document.getElementById('username_' + userId).value;
        const selectBox = document.getElementById('status_select_' + userId);
        const selectedStatus = selectBox.options[selectBox.selectedIndex].value;
        
        return confirm("Are you sure you want to change the status of " + username + " to " + selectedStatus + "?");
    }
</script> 
</html>