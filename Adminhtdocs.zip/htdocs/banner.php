<?php
    session_start();
    

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['logout_btn'])) {
        unset($_SESSION['logStatus']); 
        unset($_SESSION['name']); 
        unset($_SESSION['username']); 
        unset($_SESSION['email']); 
        header("Location: index.php?msg=Logged out");
        exit();
    }
?>

<header class="banner">
    <a href="home.php" class="logo-link">
        <img src="kc.png" alt="Kat's conner" class="banner-logo" title="Kat's conner">
    </a>
    <h1>Welcome <?php echo $_SESSION['name']?></h1>
    <form action="" method="post">
        <input type="submit" value="Log Out" name="logout_btn" class="logBtn">
    </form>
</header>