<?php 
    session_start();
    include 'adminSql.php';

    $msg="";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username=$_POST['username'];
        $password=$_POST['password'];
        $status="banned";

        $sql="SELECT * FROM users WHERE username=?";
        $prep = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($prep,"s",$username);
        mysqli_stmt_execute($prep);
        $result = mysqli_stmt_get_result($prep);

        $admin = mysqli_fetch_assoc($result);
        if($admin){
            if(2==$admin['role']){
                if ($password == $admin['password']) {
                    echo "Password Correct";
                    $_SESSION['username'] = $admin['username'];
                    $_SESSION['password2']=$admin['secPasswoed'];
                    $_SESSION['name']=$admin['name'];
                    $_SESSION['email']=$admin['email'];
                    header("Location: secLogin.php");
                    exit();
                } else {
                    $msg= "Invalid password.";
                }
            }
            else{
                $msg= "Access denied";
            }
            
            
            
        }
        else{
            $msg="User not found.";
        }
            
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Log in</title>
        <link rel="stylesheet" href="adminStyle.css">
    </head>
    <body >
        <h2>Log In</h2>
        <?php if($msg) echo "<p style='color:red;'>$msg</p>"; ?>
        <p>Enter your log in details in the fields below:</p>
        <form action="" method="post">
            <label>Username</label>
            <input type="text" name="username" required><br>
            <label>Password</label>
            <input type="password" name="password" required><br>
            <input type="submit" value="Log In">
        </form>
    </body>

</html>