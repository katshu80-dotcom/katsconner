<?php
    include 'banner.php';
    if (!isset($_SESSION['logStatus'])) {
        header("Location: login.php");
        exit(); 
    }
?>


<!DOCTYPE html>
<html>
    <head>
        <title>Home</title>
        <link rel="stylesheet" href="adminStyle.css">
    </head>
    <body>
        
        <a href="pendingP.php" >
            <button class="homeBtn"> Products Review </button>
        </a><br>
        <a href="users.php" >
            <button class="homeBtn"> Users </button>
        </a><br>
        <a href="dbManage.php" >
            <button class="homeBtn"> Other </button>
        </a>
    </body>
    
</html>