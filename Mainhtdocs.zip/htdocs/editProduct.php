<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    include 'banner.php';
    
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['updateStatus'])) {
        $sale_id = intval($_POST['sales_id']);
        $new_status = mysqli_real_escape_string($conn, $_POST['Status']);
        
        $update_query = "UPDATE sales SET status = '$new_status' WHERE sales_id = $sale_id";
        mysqli_query($conn, $update_query);
        
        echo "<script>window.location.href = window.location.href;</script>";
        exit();
    }

    if(isset($_GET['id'])) {
        $product_id = intval($_GET['id']);
        $query = "SELECT * FROM products WHERE id=$product_id";
        $result = mysqli_query($conn, $query);
        $product = mysqli_fetch_assoc($result);

        $querys = "SELECT sales.*, users.username FROM sales 
                JOIN users ON sales.user_id = users.userId 
                WHERE sales.prod_id = $product_id 
                ORDER BY sales.`date` ASC";

        $data = mysqli_query($conn, $querys);
    }
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['addCart'])) {
        $p_id = intval($_POST['product_id']);
        $qty = intval($_POST['quantity']);
        $price = floatval($_POST['price']);
        $name = strval($_POST['name']);

        $_SESSION['cart'][$p_id] = [
            'name' => $name,
            'quantity' => $qty,
            'price' => $price
        ];
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Product</title>
    <link rel="stylesheet" href="mainStyle.css?v=<?php echo time(); ?>">
</head>
<body>

    <div class="detailsCon">
        <div class="detailsImage">
            <img src="<?php echo $product['image']; ?>" alt="Product" id="preview">
        </div>

        <div class="detailsInfo">
            <form action="proccessEdit.php" method="POST" enctype="multipart/form-data">
                <label> Name:</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" ><br>
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                <label >Price: R</label>
                <input type="text" name="price" value="<?php echo $product['price']; ?>"><br>
                <label >Quantity: </label>
                <input type="text" name="quantity" value="<?php echo $product['quantity']; ?>" ><br>
                <label>Description: </label>
                <input type="text" name="details" value="<?php echo htmlspecialchars($product['details']); ?>"><br>
                <label>Image</label>
                <input type="file" name="image" id="file-path" accept="image/*"><br>
                <button type="submit" class="add-btn" name="editProduct" id="editBtn">Edit Product</button>
            </form>
        </div>
    </div>

    <div class="orders-section">
        <h2 class="order-title" style="color: #FDFDFD;">Products Ordered</h2>
        
        <?php 
        if (isset($data) && mysqli_num_rows($data) > 0):
            while ($sale = mysqli_fetch_assoc($data)): 
                $total_price = $sale['quantity'] * $sale['price'];
        ?>
                <div class="dropdown-container">
                    <button class="dropdown-btn" onclick="toggleDropdown('order_<?php echo $sale['sales_id']; ?>')">
                        <span>Username: <?php echo htmlspecialchars($sale['username']); ?></span>
                        <span>Status: <strong><?php echo htmlspecialchars($sale['status']); ?></strong> ▼</span>
                    </button>
                    
                    <div id="order_<?php echo $sale['sales_id']; ?>" class="dropdown-content">
                        <p><strong>Quantity Bought:</strong> <?php echo intval($sale['quantity']); ?></p>
                        <p><strong>Date Purchased:</strong> <?php echo $sale['date']; ?></p>
                        <p><strong>Item Price:</strong> R<?php echo number_format($sale['price'], 2); ?></p>
                        <p><strong>Total Price:</strong> R<?php echo number_format($total_price, 2); ?></p>
                        <p><strong>Delivery Address:</strong> <?php echo htmlspecialchars($sale['address']); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($sale['email']); ?></p>
                        
                        <form action="" method="POST" style="margin-top: 15px; border-top: 1px dashed #003366; padding-top: 10px;">
                            <input type="hidden" name="sales_id" value="<?php echo $sale['sales_id']; ?>">
                            <label style="font-weight: bold; color: #003366;">Update Logistics Status:</label>
                            <select name="Status" class="largenFields" style="background-color: #003366; color: #FDFDFD; padding: 5px; margin-left: 10px;">
                                <option value="Preparing" <?php if($sale['status'] == 'Preparing') echo 'selected'; ?>>Preparing</option>
                                <option value="Out for delivery" <?php if($sale['status'] == 'Out for delivery') echo 'selected'; ?>>Out for delivery</option>
                                <option value="Delivered" <?php if($sale['status'] == 'Delivered') echo 'selected'; ?>>Delivered</option>
                            </select>
                            <button type="submit" name="updateStatus" style="padding: 5px 10px; margin-left: 10px; font-weight: bold; cursor: pointer;">Save Status</button>
                        </form>
                    </div>
                </div>
        <?php 
            endwhile; 
        else: 
        ?>
            <p style="font-style: italic; color: #FDFDFD;">No orders have been placed for this product yet.</p>
        <?php endif;?>
    </div>

</body>

<script>
    const editBtn = document.getElementById('editBtn');
    
    if (editBtn) {
        editBtn.addEventListener('click', function(event){
            const userConfirmed = confirm("Are you sure you want to save these modifications to <?php echo mysqli_real_escape_string($conn, $product['name']); ?>?");
            if (!userConfirmed) {
                event.preventDefault(); 
            }
        });
    }

    document.getElementById('file-path').onchange = function(e) {
        let read = new FileReader();
        read.onload = function() {
            let preview = document.getElementById('preview');
            preview.src = read.result;
            preview.style.display = "block";
        }
        read.readAsDataURL(e.target.files[0]);
    }

    function toggleDropdown(id) {
        const orderBox = document.getElementById(id);
        if (orderBox.style.display === "block") {
            orderBox.style.display = "none";
        } else {
            orderBox.style.display = "block";
        }
    }
</script> 
</html>