<?php

include 'banner.php';
include 'mainSql.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_cart'])) {
    $p_id = intval($_POST['product_id']);
    $new_qty = intval($_POST['new_quantity']);
    
    if ($new_qty > 0) {
        $_SESSION['cart'][$p_id]['quantity'] = $new_qty;
    } else {
        unset($_SESSION['cart'][$p_id]);
    }
    header("Location: cart.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link rel="stylesheet" href="mainStyle.css">
</head>
<body>

<div class="cart-wrapper">
    <h1>Your Shopping Bag</h1>

    <?php 
    if (!empty($_SESSION['cart'])): 
        $grand_total = 0;
        $stock_error = false;
    ?>
        <table class="cart-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                foreach ($_SESSION['cart'] as $p_id => $item): 
                    $query = "SELECT quantity FROM products WHERE id = $p_id";
                    $res = mysqli_query($conn, $query);
                    $prod_info = mysqli_fetch_assoc($res);
                    $current_stock = intval($prod_info['quantity']);

                    if ($item['quantity'] > $current_stock) {
                        $_SESSION['cart'][$p_id]['quantity'] = $current_stock;
                        $item['quantity'] = $current_stock;
                        $stock_error = true;
                    }

                    $subtotal = $item['quantity'] * $item['price'];
                    $grand_total += $subtotal;
                ?>
                <tr>
                    <td>
                        <a href="productDetails.php?id=<?php echo $p_id; ?>" class="cart-product-link" style="color: white;">
                            <?php echo $_SESSION['cart'][$p_id]['name']; ?>
                        </a>
                    </td>
                    <td>R<?php echo number_format($item['price'], 2); ?></td>
                    <td>
                        <form action="" method="POST" class="cart-update-form">
                            <input type="hidden" name="product_id" value="<?php echo $p_id; ?>">
                            <select name="new_quantity" onchange="this.form.submit()">
                                <?php 
                                for ($i = 1; $i <= $current_stock; $i++) {
                                    $selected = ($i == $item['quantity']) ? 'selected' : '';
                                    echo "<option value='$i' $selected>$i</option>";
                                }
                                ?>
                            </select>
                            <input type="hidden" name="update_cart" value="1">
                        </form>
                    </td>
                    <td>R<?php echo number_format($subtotal, 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <?php if ($stock_error): ?>
            <script>alert("Some item quantities were adjusted because database stock levels changed!");</script>
        <?php endif; ?>

        <div class="cart-total-section">
            <h2>Grand Total: R<?php echo number_format($grand_total, 2); ?></h2>
            <form action="checkout.php" method="POST" id="checkoutForm">
                <button type="submit" class="checkout-btn" id="checkoutBtn">Proceed to Checkout</button>
            </form>
        </div>

    <?php else: ?>
        <p class="empty-msg">Your cart is currently empty. <a href="index.php">Go find some items!</a></p>
    <?php endif; ?>
</div>

<script>
    const checkoutForm = document.getElementById('checkoutForm');
    const isLoggedIn = <?php echo (isset($_SESSION['logStatus']) && $_SESSION['logStatus'] === "Logged in") ? 'true' : 'false'; ?>;

    if(checkoutForm) {
        checkoutForm.addEventListener('submit', function(e) {
            e.preventDefault(); 
            
            if (!isLoggedIn) {
                alert("You must be logged in to proceed to checkout!");
                window.location.href = 'login.php';
                return;
            }
            
            let confirmCheckout = confirm("Are you sure you want to proceed to checkout with these items?");
            if (confirmCheckout) {
                this.submit(); 
            }
        });
    }
</script>

</body>
</html>