<?php
session_start();
include 'banner.php'; 

if (!isset($_SESSION['logStatus']) || $_SESSION['logStatus'] !== "Logged in") {
    header("Location: login.php");
    exit();
}

$user_id = intval($_SESSION['user_id']);


$previous_page = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'viewProducts.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['saveCard'])) {
    $card_holder = mysqli_real_escape_string($conn, $_POST['card_holder']);
    $card_number = mysqli_real_escape_string($conn, $_POST['card_number']);
    $expiry_date = mysqli_real_escape_string($conn, $_POST['expiry_date']);
    $cvv = mysqli_real_escape_string($conn, $_POST['cvv']);
    $bank_name = mysqli_real_escape_string($conn, $_POST['bank_name']);
    $redirect_url = $_POST['redirect_url'];

    
    $insert_card = "INSERT INTO bank (user_id, card_no, expire_date, cv_no, bank_name, bank_holder) 
                    VALUES ($user_id, '$card_number', '$expiry_date', '$cvv', '$bank_name', '$card_holder')";

    if (mysqli_query($conn, $insert_card)) {
        echo "<script>
                alert('Payment method linked successfully!');
                window.location.href = '$redirect_url';
              </script>";
        exit();
    } else {
        echo "Database Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Link Payment Method</title>
    <link rel="stylesheet" href="mainStyle.css">
    <style>
        
    </style>
</head>
<body>

    <div class="bankFormCon">
        <h2>Add Bank Account / Card</h2>
        
        <form action="bank.php" method="POST">
            <!-- Hidden input holding the return URL destination -->
            <input type="hidden" name="redirect_url" value="<?php echo htmlspecialchars($previous_page); ?>">

            <label>Bank Name</label>
            <select name="bank_name" required>
                <option value="">-- Select Bank --</option>
                <option value="Capitec">Capitec</option>
                <option value="FNB">FNB (First National Bank)</option>
                <option value="Standard Bank">Standard Bank</option>
                <option value="Absa">Absa</option>
                <option value="Nedbank">Nedbank</option>
                <option value="TymeBank">Nedbank</option>
                <option value="African Bank">African Bank</option>
                <option value="Discovery Bank">Discovery Bank</option>
                <option value="Investec">Investec</option>
                <option value="Bank Zero">Bank Zero</option>
            </select>

            <label>Account / Card Holder Name</label>
            <input type="text" name="card_holder" placeholder="e.g. J Smith" required>

            <label>Card Number</label>
            <input type="text" name="card_number" id="cardNumberInput" maxlength="16" placeholder="xxxx xxxx xxxx xxxx" required>

            <div class="row">
                <div>
                    <label>Expiry Date</label>
                    <input type="text" name="expiry_date" maxlength="7" placeholder="MM/YYYY" required>
                </div>
                <div>
                    <label>CVV Number</label>
                    <input type="password" name="cvv" maxlength="4" placeholder="123" required>
                </div>
            </div>

            <button type="submit" name="saveCard" id="cardBtn" class="submit-bank-btn">Save & Link Account</button>
        </form>
    </div>

</body>
</html>
<script>
    const cardInput = document.getElementById('cardNumberInput');
    const cardBtn = document.getElementById('cardBtn');

    if (cardBtn) {
        cardBtn.addEventListener('click', function(){
            const userConfirmed = confirm("Are you sure you want to save these banking details?");
            
            if (!userConfirmed) {
        
                event.preventDefault(); 
            }
        });
    }

    if (cardInput) {
        cardInput.addEventListener('input', function (e) {
            
            let value = e.target.value.replace(/\D/g, '');
            
            
            let formattedValue = value.match(/.{1,4}/g);
            
            if (formattedValue) {
                
                e.target.value = formattedValue.join(' ');
            } else {
                e.target.value = '';
            }
        });
    }
</script>