<?php
session_start();

include 'mainSql.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['logStatus']) || $_SESSION['logStatus'] !== "Logged in") {
        header("Location: login.php");
        exit();
    }

    $user_id = intval($_SESSION['user_id']);
    $product_id = intval($_POST['product_id']);

    $owner_check = "SELECT * FROM products WHERE id = $product_id AND userId = $user_id";
    $owner_result = mysqli_query($conn, $owner_check);

    if (!$owner_result || mysqli_num_rows($owner_result) === 0) {
        die("Access Denied: You do not have permission to modify this item.");
    }

    $current_product = mysqli_fetch_assoc($owner_result);

    
    if (isset($_POST['name']) && trim($_POST['name']) !== "") {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
    } else {
        $name = mysqli_real_escape_string($conn, $current_product['name']);
    }

    if (isset($_POST['price']) && trim($_POST['price']) !== "") {
        $price = floatval($_POST['price']);
    } else {
        $price = floatval($current_product['price']);
    }

    if (isset($_POST['quantity']) && trim($_POST['quantity']) !== "") {
        $quantity = intval($_POST['quantity']);
    } else {
        $quantity = intval($current_product['quantity']);
    }


    if (isset($_POST['details']) && trim($_POST['details']) !== "") {
        $details = mysqli_real_escape_string($conn, $_POST['details']);
    } else {
        $details = mysqli_real_escape_string($conn, $current_product['details']);
    }

    $image_path = $current_product['image']; 
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_name = time() . '_' . basename($_FILES['image']['name']);
        $target_dir = "uploads/"; 
        $target_file = $target_dir . $file_name;

        if (move_uploaded_file($file_tmp, $target_file)) {
            $image_path = $target_file;
        }
    }

    $update_query = "UPDATE products 
                     SET name = '$name', price = $price, quantity = $quantity, details = '$details', image = '$image_path' 
                     WHERE id = $product_id AND userId = $user_id";

    if (mysqli_query($conn, $update_query)) {
        header("Location: editProduct.php?id=" . $product_id . "&update=success");
        exit();
    } else {
        echo "Database Update Error: " . mysqli_error($conn);
    }
} else {
    header("Location: viewProducts.php");
    exit();
}
?>