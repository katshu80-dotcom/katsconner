<?php
include 'banner.php';

// 1. THE LOGOUT PROCESSOR: It catches the hidden form submit before anything else loads
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'logout_user') {
    // Completely clear all session variables
    $_SESSION = array();
    
    // Destroy the session entirely
    session_destroy();
    
    // Send them straight to home as a guest
    header("Location: index.php");
    exit();
}

// 2. Standard authentication barrier check
if (!isset($_SESSION['logStatus']) || $_SESSION['logStatus'] !== "Logged in") {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings & Dashboard</title>
    <link rel="stylesheet" href="mainStyle.css?v=<?php echo time(); ?>">
</head>
<body>

<div class="settings-wrapper">
    <h1>Account Dashboard</h1>
    <p>Welcome back! Manage your shop, track your orders, and configure your account preferences below.</p>

    <div class="settings-grid">
    
        <div class="settings-card">
            <h3>My Products</h3>
            <p>Track live customer orders for items you are selling, update stock quantities, and manage fulfillment.</p>
            <a href="viewProducts.php" class="settings-btn">Manage My Shop</a>
        </div>

        <div class="settings-card">
            <h3>Purchases</h3>
            <p>View your order history, check current tracking statuses, and review your previous proof-of-payment submissions.</p>
            <a href="viewPurchases.php" class="settings-btn">View Purchases</a>
        </div>

        <div class="settings-card" style="border-color: #FF3333; display: flex; flex-direction: column; justify-content: center; align-items: center;">
            <h3>Exit Dashboard</h3>
            <p style="margin-bottom: 15px;">Securely close out your active administrative profile portal session access.</p>
            
            <!-- YOUR BUTTON: Kept exactly as a button element inside its card layout container -->
            <button class="settings-btn" id="log" style="background-color: #FF3333; color: white;">Log out</button>
        </div>

    </div>
</div>


<form id="logoutForm" method="POST" style="display: none;">
    <input type="hidden" name="action" value="logout_user">
</form>

</body>
</html>

<script>
    const log = document.getElementById('log');
    const logoutForm = document.getElementById('logoutForm');
    
    if(log && logoutForm) {
        log.addEventListener('click', function(e) {
            e.preventDefault(); 
            
            let confirmCheckout = confirm("Are you sure you want to log out?");
            if (confirmCheckout) {
        
                logoutForm.submit(); 
            }
            
        });
    }
</script>