<?php 
    include 'banner.php'; 
    

    $sql = "SELECT id, name, price, image FROM products WHERE status = 1 AND quantity > 0 LIMIT 35";
    $result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Home</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="mainStyle.css?v=<?php echo time(); ?>">
    </head>
    <body>
    
        <main class="product">
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                
                    <a href="productDetails.php?id=<?php echo $row['id']; ?>" >
                        <div class="productGrid"> 
                            <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>" title="<?php echo $row['name']; ?>" loading="lazy">
                            <div style="padding: 10px; text-align: center;">
                                <h4 style="margin: 5px 0; color: #FFCC00;"><?php echo $row['name']; ?></h4>
                                <p style="margin: 0; color: #FDFDFD;">R<?php echo $row['price']; ?></p>
                            </div>
                        </div>
                    </a>
                <?php endwhile; ?>
            <?php else: ?>
                <p>Sorry, no products avalible.</p>
            <?php endif; ?>

        </main>

    </body>
</html>
