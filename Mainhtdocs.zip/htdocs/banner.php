<?php
    session_start();
    include 'mainSql.php';
        
        
?>


<header class="banner">
    <a href="index.php" class="logo-link">
        <img src="kc.png" alt="Kat's Corner" class="banner-logo">
    </a>
    <form action="searchResults.php" method="GET" class="search-form">
        <label for="search" style="color: #FDFDFD; margin-right: 5px;">Search</label>
        <input type="text" name="query" id="search" required placeholder="Search products...">
        <button type="submit" style="display:none;">Search</button> 
    </form>
    <nav>
        <div class="dropdown">
            <form action="categoryResults.php" method="GET">
                <select name="category" id="category" onchange="if(this.value !== '') { this.form.submit(); }" required>
                    <option value="">Select Category</option>

                    <?php
                    $query = "SELECT id, name FROM category";
                    $result = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_assoc($result)){
                        echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                    }
                    ?>

                </select>
            </form>
        </div>
    </nav>
    
    <a href="cart.php" class="logo-link">
        <img src="cart.png" alt="Cart" class="cart-icon">
        <p style="color:gold"><?php 
                if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
                    $total_items = 0;
                    foreach ($_SESSION['cart'] as $p_id => $item) {
                        $total_items += intval($item['quantity']);
                    }
                    echo $total_items;
                } else {
                    echo "0";
                }
            ?>
        </p>
    </a>

    <?php if (isset($_SESSION['logStatus']) && $_SESSION['logStatus'] === "Logged in"): ?>
        <a href="settings.php" class="logo-link">
            <img src="loggedIn.png" alt="Settings" class="banner-logo" title="Settings">
        </a>
        <a href="sell.php" class="sell-link">Sell</a>
    <?php else: ?>
        <!-- ONLY shows when logged out -->
        <a href="login.php" class="logo-link">
            <img src="login.png" alt="Login" class="banner-logo" title="Log in / Sign up">
        </a>
    <?php endif; ?>
</header>