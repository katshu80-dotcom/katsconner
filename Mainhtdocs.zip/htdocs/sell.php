<?php 
    session_start();
    include 'mainSql.php';


?>





<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mainStyle.css">
</head>
<body>
    <h1>What will you be selling?</h1>
    <form action="sellerProcess.php" method="post" enctype="multipart/form-data">
        <label>Product name</label>
        <input type="text" name="name" required><br>
        <label>Product price</label>
        <input type="text" name="price" required><br>
        <label>How much quantity of the product</label>
        <input type="text" name="quantity" required><br>
        <label for="category">Catergory</label>
        <select name="category" id="category" required>
            <option value="">Select Category</option>
            <?php
                $query="SELECT id,name FROM category";
                $result = mysqli_query($conn, $query);
                while($row = mysqli_fetch_assoc($result)){
                    echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                }
            ?>
        </select><br>
        <label>Image</label>
        <input type="file" name="image" id="file-path" accept="image/*" required>
        <img id="preview" src="" alt="Preview" style="display:none; width:200px; margin-top:10px;"><br>
        <label>Product Details</label>
        <input type="text" name="details" required><br>

        <input type="submit" value="Post" id="sellBtn" class="logBtn">


    </form>


    
</body>
</html>
<script>
    const sellBtn = document.getElementById('sellBtn');
    if (sellBtn) {
        sellBtn.addEventListener('click', function(){
            const userConfirmed = confirm("Are you sure you want to post this product?");
            
            if (!userConfirmed) {
        
                event.preventDefault(); 
            }
        });
    }
    document.getElementById('file-path').onchange = function(e) {
        let read = new FileReader();
        read.onload = function() {
            let preview = document.getElementById('preview');
            preview.src = read.result;
            preview.style.display = "block";
        }
        read.readAsDataURL(e.target.files[0]);
    }
</script>