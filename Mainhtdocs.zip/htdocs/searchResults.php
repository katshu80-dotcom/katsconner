<?php

include 'banner.php';
include 'mainSql.php';

$search_word = isset($_GET['query']) ? mysqli_real_escape_string($conn, trim($_GET['query'])) : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Search Results</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mainStyle.css">
</head>
<body>

<div class="search-container" style="padding: 20px 50px;">
    <h1>Search Results for: "<?php echo htmlspecialchars($search_word); ?>"</h1>

    <?php
    if ($search_word !== '') {
        $query = "SELECT * FROM products WHERE name LIKE '%$search_word%'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            echo '<div class="product">'; 
            while ($product = mysqli_fetch_assoc($result)) {
                ?>
                <a href="productDetails.php?id=<?php echo $product['id']; ?>" style="text-decoration: none;">
                    <div class="productGrid">
                        <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
                        <div style="padding: 10px;">
                            <h3 style="margin: 0; font-size: 16px; color: #FDFDFD;"><?php echo $product['name']; ?></h3>
                            <p style="margin: 5px 0 0 0; color: #FFCC00;">R<?php echo number_format($product['price'], 2); ?></p>
                        </div>
                    </div>
                </a>
                <?php
            }
            echo '</div>';
        } else {
            echo "<p class='empty-msg' style='margin-top: 20px;'>No items found matching your search. Try checking your spelling or looking for something else!</p>";
        }
    } else {
        echo "<p class='empty-msg'>Please enter a search keyword into the navigation bar above.</p>";
    }
    ?>
</div>

</body>
</html>