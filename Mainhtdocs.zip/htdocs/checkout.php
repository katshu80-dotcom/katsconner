<?php
session_start();
include 'mainSql.php'; 

if (!isset($_SESSION['logStatus']) || $_SESSION['logStatus'] !== "Logged in") {
    header("Location: login.php");
    exit();
}

$user_id = intval($_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_order'])) {
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $bank_id = intval($_POST['bank_id']);
    $email=strval($_SESSION['email']);

    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $product_id => $item) {
            $qty = intval($item['quantity']);
            $price = floatval($item['price']);

            
            $insert_sale = "INSERT INTO sales (prod_id, user_id, email, quantity, price, address, bank_id, status) 
                            VALUES ($product_id, $user_id, '$email', $qty, $price, '$address', $bank_id, 'Preparing')";
            mysqli_query($conn, $insert_sale);
        }

        unset($_SESSION['cart']);

        echo "<script>
                alert('Payment processing simulated successfully! Your order has been placed.');
                window.location.href = 'viewProducts.php';
            </script>";
        exit();
    }
}

$card_query = "SELECT bank_id, bank_name, card_no FROM bank WHERE user_id = $user_id";
$card_result = mysqli_query($conn, $card_query);

$total_price = 0;
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_price += ($item['price'] * $item['quantity']);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="mainStyle.css">
</head>
<body>

    <div class="settings-wrapper">
        
        <a href="cart.php" class="dropbtn" style="text-decoration: none; display: inline-block; margin-bottom: 20px;">← Return to Cart</a>
        
        <div class="settings-card" style="width: 100%; max-width: 700px; margin: 0 auto;">
            <h2 class="order-title">Confirm Your Order Purchase</h2>

            <h3 style="color: #FFCC00; margin-top: 20px;">Order Summary</h3>
            <div style="margin-bottom: 25px;">
                <?php 
                if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])):
                    foreach ($_SESSION['cart'] as $p_id => $item): 
                ?>
                        <div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid rgba(255,255,0,0.2);">
                            <span><strong><?php echo htmlspecialchars($item['name']); ?></strong> (x<?php echo $item['quantity']; ?>)</span>
                            <span>R<?php echo number_format($item['price'] * $item['quantity'], 2); ?></span>
                        </div>
                <?php 
                    endforeach; 
                else:
                    echo "<p style='font-style: italic;'>Your shopping cart is currently empty.</p>";
                endif;
                ?>
            </div>

            <h3 style="text-align: right; color: #FFCC00; margin-bottom: 30px;">
                Total Amount Due: R<?php echo number_format($total_price, 2); ?>
            </h3>

            <form id="checkoutForm" action="checkout.php" method="POST" class="detailsInfo">
                
                <div>
                    <label style="display: block; font-weight: bold; margin-bottom: 8px;">Delivery or Meetup Instructions:</label>
                    <textarea name="address" class="largenFields" style="width: 100%; box-sizing: border-box; font-family: sans-serif; resize: vertical;" rows="3" placeholder="Where should the seller deliver or meet you? (e.g. Campus Library, Res Room 3B)" required></textarea>
                </div>

                <div style="margin-top: 15px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <label style="font-weight: bold;">Select Payment Method:</label>
                        <a href="bank.php" style="color: #FFCC00; font-weight: bold; text-decoration: none; font-size: 14px;">＋ Add Pay Method</a>
                    </div>
                    
                    <select name="bank_id" class="largenFields" style="width: 100%; box-sizing: border-box; background-color: #003366; color: #FDFDFD;" required>
                        <option value="" style="color: #FDFDFD;">-- Choose Saved Card --</option>
                        <?php while($card = mysqli_fetch_assoc($card_result)): 
                            $clean_card = str_replace(' ', '', $card['card_no']);
                            $last_four = substr($clean_card, -4);
                        ?>
                            <option value="<?php echo $card['bank_id']; ?>" style="color: #FDFDFD;">
                                <?php echo htmlspecialchars($card['bank_name']) . " (Ending in ...." . $last_four . ")"; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <button type="submit" name="process_order" class="checkout-btn" style="width: 100%; margin-top: 30px; font-weight: bold;" <?php echo empty($_SESSION['cart']) ? 'disabled' : ''; ?>>
                    Proceed to Payment Gateway
                </button>
            </form>
        </div>
    </div>


</body>
</html>
<script>
    const checkoutForm = document.getElementById('checkoutForm');

    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function(event) {
            const confirmPurchase = confirm("Are you sure you want to proceed with this purchase selection?");
            if (!confirmPurchase) {
                event.preventDefault(); 
            }
        });
    }
</script>