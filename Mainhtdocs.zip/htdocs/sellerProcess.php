<?php
    session_start();
    include 'mainSql.php';

    $name=$_POST["name"];
    $price=$_POST["price"];
    $quantity=$_POST["quantity"];
    $category=$_POST["category"];
    $details=$_POST["details"];
    $imageNam=$_FILES["image"]['name'];
    $imageTep=$_FILES["image"]['tmp_name'];
    $uFolder = "uploads/" . $imageNam;
    $userId=$_SESSION['user_id'];
    if (move_uploaded_file($imageTep, $uFolder)) {
        $sql = "INSERT INTO products (name, image, price, quantity, category_id, details, status,userId,flags) VALUES (?, ?, ?, ?, ?, ?, 0,?,0)";
        
        $prep = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($prep, "ssdiisi", $name, $uFolder, $price, $quantity, $category, $details, $userId);
        
        if (mysqli_stmt_execute($prep)) {
            echo "Product submitted! Waiting for admin approval.";
            header("Location: index.php");
        } else {
            echo "Database error: Could not save product.";
        }
    }
    
?>