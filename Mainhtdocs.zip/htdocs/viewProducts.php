<?php
    include 'banner.php';
    if(isset($_SESSION['user_id']) ) {
        $user_id = intval($_SESSION['user_id']);
        $query = "SELECT * FROM products WHERE userId=$user_id";
        $result = mysqli_query($conn, $query);
    } 
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>My Products</title>
        <link rel="stylesheet" href="mainStyle.css?v=<?php echo time(); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>

        <h1> Edit Products </h1>

    
        <main class="product">
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                
                    <a href="editProduct.php?id=<?php echo $row['id']; ?>" style="text-decoration: none;">
                        <div class="productGrid"> 
                            <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>" title="<?php echo $row['name']; ?>" loading="lazy">
                            <div style="padding: 10px; text-align: center;">
                                <h4 style="margin: 5px 0; color: #FFCC00;"><?php echo htmlspecialchars($row['name']); ?></h4>
                                <p style="margin: 0; color: #FDFDFD;">R<?php echo number_format($row['price'], 2); ?></p>
                                <p style="margin: 0; color: #FDFDFD;">
                                    <?php 
                                        if ($row['status'] == 1) {
                                            echo "<span style='color: #33FF33;'>Approved</span>";
                                        } elseif ($row['status'] == 2) {
                                            echo "<span style='color: #FF3333;'>Denied</span>";
                                        } else {
                                            echo "<span style='color: #AAAAAA;'>Yet to be reviewed</span>"; 
                                        }
                                    ?>
                                </p>
                            </div>
                        </div>
                    </a>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="empty-msg" style="grid-column: 1 / -1; text-align: center;">Sorry, Haven't sold products yet</p>
            <?php endif; ?>

        </main>

    </body>
</html>