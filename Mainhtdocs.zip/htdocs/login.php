<?php 
    session_start();
    include 'mainSql.php';

    $msg="";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username=$_POST['username'];
        $password=$_POST['password'];
        $status="Banned";

        $sql="SELECT * FROM users WHERE username=?";
        $prep = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($prep,"s",$username);
        mysqli_stmt_execute($prep);
        $result = mysqli_stmt_get_result($prep);

        $user = mysqli_fetch_assoc($result);
        if($user){
            if ($status==$user['status']){
                $msg="User is banned. Cannot log in";
            }else{
                if ($password == $user['password']) {
                    echo "Login successful!";
                    $_SESSION['user_id'] = $user['userId'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['name']=$user['name'];
                    $_SESSION['email']=$user['email'];
                    $_SESSION['logStatus']="Logged in";
                    header("Location: index.php");
                    exit();
                } else {
                    $msg= "Invalid password.";
                }
            }
        }
        else{
            $msg="User not found.";
        }
            
    }

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Log in</title>
        <link rel="stylesheet" href="mainStyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body >
        <h2>Log In</h2>
        <?php if($msg) echo "<p style='color:red;'>$msg</p>"; ?>
        <p>Enter your log in details in the fields below:</p>
        <form action="" method="post">
            <label>Username</label>
            <input type="text" name="username" required><br>
            <label>Password</label>
            <input type="password" name="password" required><br>
            <input type="submit" value="Log In">
        </form>
        <h2>Not registerd?</h2>
        <p>Click the button below:</p>
        <a href="signup.php">
            <button>Sigh Up</button>
        </a><br>
        <a href="index.php" >
            <button>Cancel</button>
        </a>
    </body>

</html>