<?php 
    session_start();
    include 'mainSql.php';

    $msg = "";
    if(isset($_SESSION['otp'])) {
        echo "Testing: Your OTP is " . $_SESSION['otp'];
    }
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $user_input = $_POST['otp'];

        if ($user_input == $_SESSION['otp']) {
            $sql = "INSERT INTO users (username, password, email, phoneNum, name, status,role) VALUES (?, ?, ?, ?, ?, 'active',1)";
            $prep = mysqli_prepare($conn, $sql);
            
            mysqli_stmt_bind_param($prep, "sssss", 
                $_SESSION['username'], 
                $_SESSION['password'], 
                $_SESSION['email'], 
                $_SESSION['phoneNum'], 
                $_SESSION['name'], 
            );

            if (mysqli_stmt_execute($prep)) {
                unset($_SESSION['otp']); 
                header("Location: login.php?msg=Success");
                exit();
                
            } else {
                $msg = "Error:". mysqli_error($conn);
            }
        } else {
            $msg = "Invalid OTP code. Please try again.";
        }
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Log in</title>
        <link rel="stylesheet" href="mainStyle.css">
    </head>
    <body>
        <h1>Enter OTP</h1>
        <?php if($msg) echo "<p style='color:red;'>$msg</p>"; ?>
        <form action="" method="post">
            <label>OTP</label>
            <input type="password" name="otp" required>
            <input type="submit" value="Verify">
        </form>
    </body>
</html>