<?php
   session_start();
   include 'mainSql.php';

    $msg="";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username= $_POST['username'];
        $password=$_POST['password'];
        $email=$_POST['email'];
        $phoneNum=$_POST['phoneNum'];
        $name=$_POST['name'];
        $status="banned";

        $sql="SELECT * FROM users WHERE username=?";
        $prep = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($prep,"s",$username);
        mysqli_stmt_execute($prep);
        $result = mysqli_stmt_get_result($prep);

        $user = mysqli_fetch_assoc($result);
        if($user){
            $msg="Username already exists. Please enter a new one";
        }else{
            $sql="SELECT status FROM users WHERE email=?";
            $prep = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($prep,"s",$email);
            mysqli_stmt_execute($prep);
            $check = mysqli_stmt_get_result($prep);
            $banned = mysqli_fetch_assoc($check);
            if($banned && $status==$banned){
                $msg="Sorry, user may not register. Email is from a banned account.";
            }else{
                $otp = rand(100000, 999999);
                $_SESSION['username'] =$username; 
                $_SESSION['name']=$name;
                $_SESSION['password']=$password;
                $_SESSION['email']=$email;
                $_SESSION['phoneNum']=$phoneNum;
                $_SESSION['otp']=$otp;

                header("Location: verifyOtp.php");
                exit();
            }
            
            
        }
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Log in</title>
        <link rel="stylesheet" href="mainStyle.css">
    </head>
    <body >
        <h2>Sign up</h2>
        <?php if($msg) echo "<p style='color:red;'>$msg</p>"; ?>
        <p>Enter your details in the fields below:</p>
        <form action="" method="post">
            <label>Username</label>
            <input type="text" name="username" required><br>
            <label>Password</label>
            <input type="password" name="password" required><br>
            <label>Name</label>
            <input type="text" name="name" required><br>
            <label>Email</label>
            <input type="email" name="email" required><br>
            <label>Phone Number</label>
            <input type="tel" name="phoneNum" required><br>
            <input type="submit" value="sign up">
        </form>
        <h2>Already have an account?</h2>
        <p>Click the button below:</p>
        <a href="login.php">
            <button>Log In</button>
        </a><br>
        <a href="index.php" >
            <button>Cancel</button>
        </a>
    </body>
</html>
