<?php
    include 'banner.php';
    if(isset($_GET['category']) && $_GET['category'] !== '') {
        $category_id = intval($_GET['category']);
        $query = "SELECT * FROM products WHERE category_id=$category_id";
        $result = mysqli_query($conn, $query);
    } else {
        
        header("Location: index.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Category Results</title>
        <link rel="stylesheet" href="mainStyle.css?v=<?php echo time(); ?>">
    </head>
    <body>

    
        <main class="product">
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                
                    <a href="productDetails.php?id=<?php echo $row['id']; ?>" style="text-decoration: none;">
                        <div class="productGrid"> 
                            <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>" title="<?php echo $row['name']; ?>" loading="lazy">
                            <div style="padding: 10px; text-align: center;">
                                <h4 style="margin: 5px 0; color: #FFCC00;"><?php echo htmlspecialchars($row['name']); ?></h4>
                                <p style="margin: 0; color: #FDFDFD;">R<?php echo number_format($row['price'], 2); ?></p>
                            </div>
                        </div>
                    </a>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="empty-msg" style="grid-column: 1 / -1; text-align: center;">Sorry, no products available in this category right now.</p>
            <?php endif; ?>

        </main>

    </body>
</html>