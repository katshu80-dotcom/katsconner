<?php
    include 'banner.php';
    if(isset($_SESSION['user_id']) ) {
        $user_id = intval($_SESSION['user_id']);
        $query = "SELECT sales.*, products.name, products.image, products.price AS original_price 
                  FROM sales 
                  JOIN products ON sales.prod_id = products.id 
                  WHERE sales.user_id = $user_id 
                  ORDER BY sales.sales_id DESC";
        $result = mysqli_query($conn, $query);
    } 
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>My Purchases</title>
        <link rel="stylesheet" href="mainStyle.css?v=<?php echo time(); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>

        <h1>My Purchases</h1>

        <main class="product">
            <?php if (isset($result) && $result && mysqli_num_rows($result) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <a href="purchase.php?id=<?php echo $row['sales_id']; ?>" style="text-decoration: none;">
                        <div class="productGrid"> 
                            <img src="<?php echo $row['image']; ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" title="<?php echo htmlspecialchars($row['name']); ?>" loading="lazy">
                            <div style="padding: 10px; text-align: center;">
                                <h4 style="margin: 5px 0; color: #FFCC00;"><?php echo htmlspecialchars($row['name']); ?></h4>
                                <p style="margin: 0; color: #FDFDFD;">Qty: <?php echo intval($row['quantity']); ?></p>
                                <p style="margin: 0; color: #FDFDFD;">Total: R<?php echo number_format($row['price'] * $row['quantity'], 2); ?></p>
                                <p style="margin: 5px 0 0 0;">
                                    <?php 
                                        if ($row['status'] == 'Delivered') {
                                            echo "<span style='color: #33FF33; font-weight: bold;'>Delivered</span>";
                                        } elseif ($row['status'] == 'Out for delivery') {
                                            echo "<span style='color: #FFCC00; font-weight: bold;'>Out for Delivery</span>";
                                        } else {
                                            echo "<span style='color: #AAAAAA; font-weight: bold;'>Preparing</span>"; 
                                        }
                                    ?>
                                </p>
                            </div>
                        </div>
                    </a>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="empty-msg" style="grid-column: 1 / -1; text-align: center; color: #FDFDFD; font-style: italic;">You haven't made any purchases yet.</p>
            <?php endif; ?>
        </main>

    </body>
</html>